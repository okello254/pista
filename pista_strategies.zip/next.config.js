module.exports = {
  // ... your Next.js configuration options here
};
