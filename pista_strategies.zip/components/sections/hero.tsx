import { Hero } from "../hero";
// import { Clients } from "../clients";
export const HeroSection = () => {
  return (
    <div className="w-full">
      <div className=" mx-auto pt-[55px] md:pt-[95px]">
        <Hero />
      </div>
      {/* <Clients /> */}
    </div>
  );
};
