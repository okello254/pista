import Choose from "../choose";
export const ChooseSection = () => {
  return (
    <div className="relative flex flex-row px-4 items-center justify-stretch w-full pt-[35px] md:pt-[70px] md:px-10">
      <Choose />
    </div>
  );
};
