const Blog = () => {
  return <h1 className="">Comming soon...!</h1>;
};

export default Blog;
