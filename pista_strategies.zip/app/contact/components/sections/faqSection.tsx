import FAQSection from "../faq";
export const FaqSection = () => {
  return (
    <section className="w-full px-4 md:px-10">
      <FAQSection />
    </section>
  );
};
